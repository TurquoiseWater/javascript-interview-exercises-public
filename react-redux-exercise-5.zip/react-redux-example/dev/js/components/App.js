import React from 'react';
import CompanyList from '../containers/company-list';
import CompanyDetails from '../containers/company-detail';
require('../../scss/style.scss');

const App = () => (
    <div>

        <h2>Companies</h2>
        <CompanyList />
        <hr />
        <h2>Details</h2>
        <CompanyDetails />
    </div>
);

export default App;
