import React, {Component} from 'react';
import {connect} from 'react-redux';

/*
 * We need "if(!this.props.user)" because we set state to null by default
 * */

class CompanyDetail extends Component {
    render() {
        if (!this.props.company) {
            return (<div>Choose a company...</div>);
        }
        return (
            <div>
                <img src={this.props.company.thumbnail} />
                <h2>{this.props.company.name}</h2>
                <h2>ID: {this.props.company.id}</h2>
                <h2>Location: {this.props.company.location}</h2>
            </div>
        );
    }
}

// "state.activeCompany" is set in reducers/index.js
function mapStateToProps(state) {
    return {
        company: state.activeCompany
    };
}

export default connect(mapStateToProps)(CompanyDetail);
