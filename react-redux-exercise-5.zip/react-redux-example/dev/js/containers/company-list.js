import React, {Component} from 'react';
import {bindActionCreators} from 'redux';
import {connect} from 'react-redux';
import {selectCompany} from '../actions/index'


class CompanyList extends React.Component {

    constructor(){
        super();
        this.state = {

            search: "Type your location"
        };

    }

    updateSearch(event){
        this.setState({search: event.target.value.substr(0,30)})
    }

    renderList() {
        let filteredLocations = this.props.companies.filter(
            (company) =>{
                return company.location.toLowerCase().indexOf(this.state.search.toLowerCase()) !== -1;
            }
        );
        return filteredLocations.map((company) => {
            return (
                <li
                    key={company.id}
                    onClick={() => this.props.selectCompany(company)}
                >
                    {company.name}
                </li>
            );
        });
    }

    render() {
        return (
            <div>
            <ul id="list">
                {this.renderList()}
            </ul>
                <h2>Filter</h2>
                <input type="text" value={this.state.search}
                onChange={this.updateSearch.bind(this)} />
            </div>
        );
    }

}

// Get apps state and pass it as props to CompanyList
//      > whenever state changes, the CompanyList will automatically re-render
function mapStateToProps(state) {
    return {
        companies: state.companies
    };
}

// Get actions and pass them as props to to CompanyList
//      > now UserList has this.props.selectCompany
function matchDispatchToProps(dispatch){
    return bindActionCreators({selectCompany: selectCompany}, dispatch);
}

// We don't want to return the plain CompanyList (component) anymore, we want to return the smart Container
//      > CompanyList is now aware of state and actions
export default connect(mapStateToProps, matchDispatchToProps)(CompanyList);
