export const selectCompany = (company) => {
    console.log("You clicked on: ", company.name);
    return {
        type: 'COMPANY_SELECTED',
        payload: company
    }
};
